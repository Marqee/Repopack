# pckage
Is a library created to upload all my python coding work.

## recursion
File created for all recursion code.
'pip install git+'

## sorting
File created for all sorting algorithms created.
