'''Sum of array'''
sum_array([3,6,9,4,5,6])== 33

''' nth value of Fibonacci sequesnce'''
fibonacci(8)==21

'''factorial on n'''
factorial(5)== 120

'''reverse string'''
reverse('Hello World') == 'dlroW olleH'

'''sort an array'''
bubble_sort([9,2,5,4,6,7,3])==[2, 3, 4, 5, 6, 7, 9]

'''merge_sort an array'''
merge_sort([9,2,1,4,6,7,3])==[1, 2, 3, 4, 6, 7, 9]

'''quick_sort an array'''
quick_sort([9,2,1,4,6,7,3])==[1, 2, 3, 4, 6, 7, 9])
